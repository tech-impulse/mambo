
var host = "http://bus.grupoareas.com:8084/v0.1";
//var port = "8086";
var token = "";
var versionApp = "1.1.5"; //  27/05/2014
var tiempoRecargaBD = 360; // Horas en minutos para recargar la base de datos
var transactionId = "";
var tiempoSincronismo= 500000;

var TIPO_TEMPORAL_ORDER=0;
var TIPO_TEMPORAL_TEMPLATE=1;
var TIPO_TEMPORAL_DRAFT=2;

/*
//var host = "http://bus.grupoareas.com:8084/v0.1";
var host = "http://api.grupoareas.com:";
//var port = "8086";
var token = "token=dGhsbG9icmU6MTM3NzY0MDIyMDY5NDo3OGQ0MWE4NTE4ZDNlMmM5MzJkNjczYjU0MDQ2MGEzMg";
*/

// PERMISOS DE USUARIO 

var READ_PURCHASE_CENTER="";
var READ_VENDOR="";
var READ_ITEM="";
var READ_ORDER_STATUS="";
var READ_TEMPLATE="";
var DELETE_ORDER="";
var DELETE_DRAFT="";
var DELETE_TEMPLATE="";
var UPDATE_TEMPLATE="";

//POP UP TAM
var TIME_OUT="";

// SETTINGS
/*
var SHOW_PAR_STOCK_VALUE="";
var SHOW_PAR_STOCK_VALUE="";
var NUMBER_OF_DECIMALS="";
var DECIMAL_MARK="";
var CURRENCY="";
var THOUSANDS_MARK="";
var DATE_FORMAT="";
var CURRENCY_SIGN_PLACE="";
var EMAIL_ADDRESS="";*/